=== TP Hadoop - WordCount ===

1. Copier poeme.txt sur HDFS :
hdfs dfs -mkdir -p /user/hduser
hdfs dfs -put poeme.txt /user/hduser/

2. Compiler le code :
chmod +x build.sh
./build.sh

3. Lancer le job :
hadoop jar build/wcount.jar WCount /user/hduser/poeme.txt /user/hduser/output

4. Voir les résultats :
hdfs dfs -cat /user/hduser/output/part-r-00000
