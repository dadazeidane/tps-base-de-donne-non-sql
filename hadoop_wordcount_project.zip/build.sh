#!/bin/bash
HADOOP_CLASSPATH=$(hadoop classpath)
mkdir -p build
javac -classpath $HADOOP_CLASSPATH -d build WCount.java
cd build
jar -cvf wcount.jar *.class
echo "Compilation terminée. Fichier généré : build/wcount.jar"
