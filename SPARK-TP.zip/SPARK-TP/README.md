# TP Spark – Amis Communs

Ce projet est un TP (Travail Pratique) d'introduction à **Apache Spark** basé sur l’analyse d’un **graphe social**.  
Il permet de détecter les **amis communs entre deux utilisateurs** à partir d’un fichier texte contenant les relations d’amitié.

## 📁 Structure du projet

```
SPARK-TP/
├── tp_spark.py           # Script principal en PySpark
├── mini_tp_spark.txt     # Fichier texte contenant les utilisateurs et leurs amis
├── output_tp/            # Répertoire généré automatiquement par Spark avec les résultats
└── README.md             # Ce fichier de documentation
```

## ⚙️ Technologies utilisées

- **Apache Spark** 3.x (en mode local)
- **PySpark** (interface Python de Spark)
- **Linux / Ubuntu ou macOS / Windows avec WSL**
- Données en format **texte brut**

## 📄 Contenu du fichier `mini_tp_spark.txt`

```
1    2,3,4,5
2    1,3,4
3    1,2,4
4    1,2,3
5    1
```

## 🚀 Exécution du script

```bash
rm -r output_tp
/opt/spark/bin/spark-submit tp_spark.py
```

## 📌 Objectif du TP

Calculer les amis communs entre deux utilisateurs spécifiques (ex. : 1 et 2).


