from pyspark import SparkContext

sc = SparkContext("local", "TP Spark - Amis Communs")

# Charger les données
lines = sc.textFile("tp_spark.txt")

# Fonction pour parser chaque ligne
def parse_line(line):
    parts = line.strip().split("\t")
    if len(parts) < 3:
        return None
    user_id = parts[0]
    name = parts[1]
    friends = set(parts[2].split(","))
    return (user_id, (name, friends))

# Fonction pour générer les paires
def generate_pairs(record):
    user_id, (name, friends) = record
    pairs = []
    for friend in friends:
        key = tuple(sorted((user_id, friend)))
        pairs.append((key, friends))
    return pairs

# Traitement des données
parsed = lines.map(parse_line).filter(lambda x: x is not None)
pairs = parsed.flatMap(generate_pairs)
grouped = pairs.reduceByKey(lambda x, y: x.intersection(y))

# Filtrer pour la paire spécifique ('1', '2')
result = grouped.filter(lambda x: x[0] == ('1', '2')).collect()

# Afficher et enregistrer
for pair, friends in result:
    print(f"Paire: {pair[0]} (Sidi), {pair[1]} (Mohamed) -> Amis communs: {', '.join(friends) if friends else 'Aucun'}")

with open("output_tp/result.txt", "w") as f:
    for pair, friends in result:
        ligne = f"Paire: {pair[0]} (Sidi), {pair[1]} (Mohamed) -> Amis communs: {', '.join(friends) if friends else 'Aucun'}\n"
        f.write(ligne)

sc.stop()
